<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>registro de usuarios</title>
</head>
<style>
	
	h1
	{
color: darkmagenta;

text-align: center;

}
.container
{

	 color: darkmagenta;;
	border: solid;
	text-align: center; 
	border-color: black;

} 
form{
	background-color:beige  ;
}
button{
	color: darkmagenta;
	background:grey ;
	text-align: center;
}
label{
	text-align: center;
}


</style>
<body>
	<form class="container" action="../controladores/agregardocentes.php" method="POST">
			<h1>registro de usuarios</h1>
		
			<label>Nombre</label>
			<input type="text" name="nombredocente">
		
		<hr>
			<label>apellido</label>
			<input type="text" name="apellidodocente">
			
		<hr>

		
			<label>digite numero de documento</label>
			<input type="text" name="documentodocente">
		

		<hr>
	
			<label>correo electronico</label>
			<input type="text" name="correodocente">
		

		
		<hr>
			<label>materia</label>
			<input type="text" name="materiadocente">
	

		<hr>

			<label>usuario</label>
			<input type="text" name="usuariodocente">

	
		<hr>

		
			<label>contraseña</label>
			<input type="password" name="contrasenadocente">
		
		
		<hr>
			<label>Perfil</label>

				<label for="Perfil"></label>
				<select class="form-select" name="Perfildocente">

		<hr>
				<option selected>Elegir opcion</option>
				<option value="docente">docente</option>
				<option value="administrador">administrador</option>

			</select>

		<hr>
				<label>Docente</label>

				<label for="Estado"></label>
				<select class="form-select" name="Estadodocente">

				<option selected>Elegir opcion</option>
				<option value="activo">activo</option>
				<option value="inactivo">inactivo</option>
			</select>
	
		<hr>
		
			<button type="submit">Registrar</button>
		</div>
	</form>
</body>
</html>