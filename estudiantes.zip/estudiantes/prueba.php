<?php 
	
	include_once('Conexion.php');


	$db = new Conexion();




?>