<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>registro de usuarios</title>
</head>
<body>
	<form class="container" action="../controladores/agregarusuarios.php" method="POST">
			<h1>registro de usuarios</h1>
		<hr>
			<label>Nombre</label>
			<input type="text" name="Nombre">
		<hr>

		
			<label>apellido</label>
			<input type="text" name="apellido">
		<hr>
		
			<label>usuario</label>
			<input type="text" name="usuario">
		<hr>

		
			<label>contraseña</label>
			<input type="password" name="contraseña">
	<hr>
	
		
			<p>Perfil</p>

				<label for="Perfi"></label>
				<select class="form-select" name="Perfil">

				<option selected>Elegir opcion</option>
				<option value="administrador">Administrador</option>
				<option value="docentes">Docentes</option>

			</select>
<hr>

		
			<p>Estado</p>

				<label for="Estado"></label>
				<select class="form-select" name="Estado">

				<option selected>Elegir opcion</option>
				<option value="activo">activo</option>
				<option value="inactivo">inactivo</option>
			</select>
	<hr>

		
		<button type="submit">Agregar</button>	
		
	</form>
</body>
<style>
	
	h1
	{
color: darkmagenta;

text-align: center;

}
.container
{

	 color: darkmagenta;;
	border: solid;
	text-align: center; 
	border-color: black;

} 
form{
	background-color:beige  ;
}
button{
	color: darkmagenta;
	background:grey ;
}


</style>
</html>