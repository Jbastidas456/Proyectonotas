<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<title>registro de estudiantes</title>
</head>
<body>
	<?php
        require_once('../../Conexion.php');
        require_once('../../consultas.php');

        $consul = new Consulta();
    ?>

	<form class="container" action="../controladores/agregarestudiantes.php" method="POST">

			<h1>registro de estudiantes</h1>

	
			<label>Nombre</label>
		<input type="text" name="nombreestudiante">
		
		<hr>
		
			<label>apellido</label>
			<input type="text" name="apellidoestudiante">
		
	<hr>
		
			<label>Documento</label>
			<input type="text" name="DOCU">
		
	<hr>
		
			<label>correo</label>
			<input type="text" name="correoestudiante">
		
			<hr>
		
 	  	<label for="Materia">Materia</label>
	 	  	<select name="materiaestudiante" class="form-control input-lg" id="Materia">
	 	  		<option>seleccionar</option>

			 	  	<?php 
						 		$mate = $consul->getmaterias();
						 		if($mate != null)
								{
									foreach($mate as $ma){

					?>
					<option value="<?php echo $ma['Nombremate'];?>"><?php echo $ma['Nombremate']; ?></option>

					 <?php 
							}
						}
		 	  		?>
	 	  	</select>
 	  	

			<hr>
	 	  <label for="Docente">Docente</label>
		 	  <select name="docenteestudiante" class="form-control input-lg" id="Docente">
					<option>seleccionar</option>

			 	  		<?php 
						 		$doc = $consul->getdocentes();
						 		if($doc != null)
								{
									foreach($doc as $do){

					?>
					<option value="<?php echo $do['Nombreusu'];?>"><?php echo $do['Nombreusu']; ?></option>

					 <?php 
							}
						}
		 	  		?>
		 	  </select>
 		
	<hr>
		
			<label>Promedio</label>
			<input type="number" name="promedioestudiante">
		
	<hr>
		
			<label>Fecha_registro</label>
			<input type="date" name="fech">
		
	<hr>
		<button type="submit">Agregar</button>	
		</form>
</body>
<style>
	
	h1
	{
color: darkmagenta;

text-align: center;

}
.container
{

	 color: darkmagenta;;
	border: solid;
	text-align: center; 
	border-color: black;

} 
form{
	background-color:beige  ;
}
button{
	color: darkmagenta;
	background:grey ;
}


</style>

</html>